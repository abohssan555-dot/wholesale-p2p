import React, { useState, useEffect, useCallback } from "react";
import { Navigate, Link } from "react-router-dom";
import { supabase } from "./supabaseClient.js";
import { useIdleLogout } from "./useIdleLogout.js";
import {
  Package, Search, ShoppingCart, Plus, Minus, X, Loader2,
  Store, LogOut, Home, CheckCircle2, AlertTriangle, Wallet, Star,
} from "lucide-react";

const T = {
  ink: "#14213B",
  paper: "#F6F3EC",
  paperDeep: "#EFE9DA",
  line: "#DCD5C4",
  seal: "#B8862B",
  sealDeep: "#8C6018",
  good: "#2F6F4E",
  goodBg: "#E7F1EA",
  bad: "#A23B2E",
  badBg: "#F6E8E5",
  sub: "#5B5748",
};

function useFonts() {
  useEffect(() => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href =
      "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap";
    document.head.appendChild(link);
    return () => document.head.removeChild(link);
  }, []);
}

const CATEGORIES = [
  { id: "", label: "كل الفئات" },
  { id: "beverages", label: "مشروبات وعصائر" },
  { id: "dairy", label: "ألبان وأجبان" },
  { id: "grains_rice", label: "أرز وحبوب" },
  { id: "canned_goods", label: "معلبات" },
  { id: "cleaning", label: "منظفات ومستلزمات منزلية" },
  { id: "snacks", label: "وجبات خفيفة وحلويات" },
  { id: "fresh_produce", label: "خضار وفواكه" },
  { id: "bakery", label: "مخابز" },
  { id: "personal_care", label: "عناية شخصية" },
  { id: "plastics", label: "بلاستيك ومستلزمات تعبئة" },
  { id: "hardware", label: "خردوات وأدوات" },
  { id: "other", label: "أخرى" },
];

const PAGE_SIZE = 20;
const CART_KEY = "asnaf-cart";

function loadCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY) || "[]");
  } catch {
    return [];
  }
}
function saveCart(items) {
  localStorage.setItem(CART_KEY, JSON.stringify(items));
}

function ComparePricesModal({ catalogId, productName, currentTraderId, onClose, onAdd }) {
  const [offers, setOffers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("trader_listings")
      .select("id, quantity, wholesale_price, units_per_carton, base_unit_name, sub_unit_name, trader_id, catalog_id, product_catalog!inner(name, status), profiles!trader_id!inner(store_name, city, store_launch_status, avg_rating, ratings_count)")
      .eq("catalog_id", catalogId)
      .eq("active", true)
      .eq("profiles.store_launch_status", "launched")
      .then(({ data }) => {
        const sorted = (data || []).sort(
          (a, b) => a.wholesale_price / (a.units_per_carton || 1) - b.wholesale_price / (b.units_per_carton || 1)
        );
        setOffers(sorted);
        setLoading(false);
      });
  }, [catalogId]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6" style={{ background: "rgba(20,33,59,0.55)" }} onClick={onClose}>
      <div className="w-full max-w-sm rounded-xl p-5 max-h-[80vh] overflow-y-auto" style={{ background: "#fff" }} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-1">
          <span className="text-sm font-semibold" style={{ color: T.ink }}>مقارنة أسعار — {productName}</span>
          <button onClick={onClose}><X size={18} style={{ color: T.sub }} /></button>
        </div>
        <div className="text-[11px] mb-4" style={{ color: T.sub }}>مرتّبة من الأرخص للأغلى، من كل التجّار المتوفر عندهم هذا الصنف</div>

        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="animate-spin" size={18} style={{ color: T.sealDeep }} /></div>
        ) : (
          <div className="flex flex-col gap-2">
            {offers.map((o, i) => (
              <div key={o.id} className="flex items-center gap-3 p-3 rounded-lg" style={{ background: i === 0 ? T.goodBg : T.paper, border: `1px solid ${i === 0 ? "#BFE0CE" : T.line}` }}>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium flex items-center gap-1" style={{ color: T.ink }}>
                    <Store size={11} style={{ color: T.sealDeep }} /> {o.profiles?.store_name || "متجر غير مسمّى"}
                    {i === 0 && <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: T.good, color: "#fff" }}>الأرخص</span>}
                  </div>
                  <div className="text-[10px]" style={{ color: T.sub }}>{o.profiles?.city || ""} · متوفر: {o.quantity * (o.units_per_carton || 1)} {o.sub_unit_name || "وحدة"}</div>
                </div>
                <span className="text-sm font-semibold shrink-0" style={{ fontFamily: "'JetBrains Mono', monospace", color: T.ink }}>{(o.wholesale_price / (o.units_per_carton || 1)).toFixed(2)} ر.س/{o.sub_unit_name || "وحدة"}</span>
                <button
                  onClick={() => { onAdd(o, 1); onClose(); }}
                  disabled={o.quantity <= 0}
                  className="text-[11px] font-medium px-2.5 py-1.5 rounded-lg shrink-0"
                  style={{ background: o.quantity <= 0 ? T.paperDeep : T.ink, color: o.quantity <= 0 ? T.sub : "#fff" }}
                >
                  إضافة
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ProductRow({ listing, onAdd, inCart }) {
  const unitsPerCarton = listing.units_per_carton || 1;
  const baseUnit = listing.base_unit_name || "كرتون";
  const subUnit = listing.sub_unit_name || "وحدة";
  const piecePrice = listing.wholesale_price / unitsPerCarton;
  const availablePieces = listing.quantity * unitsPerCarton;
  const hasCartons = unitsPerCarton > 1;
  const [cartonMode, setCartonMode] = useState(true); // وضع الكرتون الكامل (افتراضي) مقابل وضع الكمية الجزئية
  const [cartonCount, setCartonCount] = useState(1); // بوضع الكرتون: عدد الكراتين
  const [partialQty, setPartialQty] = useState(1); // بوضع الجزئي: عدد الوحدة الجزئية المختارة من القائمة
  const [qty, setQty] = useState(1); // يُستخدم فقط لو المنتج بدون كرتون أصلاً (unitsPerCarton = 1)
  const [showCompare, setShowCompare] = useState(false);

  const maxCartons = listing.quantity; // كراتين متاحة
  const finalQty = !hasCartons ? qty : cartonMode ? cartonCount * unitsPerCarton : partialQty;

  return (
    <>
    <div className="flex items-center gap-4 p-4 rounded-xl" style={{ background: "#fff", border: `1px solid ${T.line}` }}>
      <div className="w-11 h-11 rounded-lg flex items-center justify-center shrink-0" style={{ background: T.paperDeep }}>
        <Package size={18} style={{ color: T.sealDeep }} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-semibold truncate" style={{ color: T.ink }}>{listing.product_catalog.name}</div>
        <div className="text-[11px] flex items-center gap-1 mt-0.5" style={{ color: T.sub }}>
          <Store size={11} /> {listing.profiles?.store_name || "متجر غير مسمّى"} · {listing.profiles?.city || ""}
          {listing.profiles?.ratings_count > 0 && (
            <span className="flex items-center gap-0.5" style={{ color: T.seal }}>
              <Star size={10} fill={T.seal} /> {listing.profiles.avg_rating} ({listing.profiles.ratings_count})
            </span>
          )}
        </div>
        {hasCartons && (
          <div className="text-[10px] mt-0.5" style={{ color: T.sub }}>ال{baseUnit} = {unitsPerCarton} {subUnit} · سعر ال{baseUnit} {listing.wholesale_price} ر.س</div>
        )}
        <button onClick={() => setShowCompare(true)} className="text-[10px] font-medium mt-1 underline" style={{ color: T.sealDeep }}>
          قارن مع تجّار آخرين
        </button>
      </div>
      <div className="text-left shrink-0">
        <div className="text-sm font-semibold" style={{ fontFamily: "'JetBrains Mono', monospace", color: T.ink }}>
          {piecePrice.toFixed(2)} <span className="text-[11px] font-normal" style={{ color: T.sub }}>ر.س/{subUnit}</span>
        </div>
        <div className="text-[10px]" style={{ color: T.sub }}>متوفر: {availablePieces} {subUnit}</div>
      </div>

      {availablePieces > 0 && !hasCartons && (
        <div className="flex items-center gap-1 shrink-0">
          <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="w-6 h-6 rounded flex items-center justify-center" style={{ background: T.paper, border: `1px solid ${T.line}` }}>
            <Minus size={11} />
          </button>
          <input
            type="number"
            value={qty}
            onChange={(e) => setQty(Math.max(1, Math.min(availablePieces, Number(e.target.value) || 1)))}
            className="text-xs w-10 text-center rounded outline-none"
            style={{ fontFamily: "'JetBrains Mono', monospace", background: T.paper, border: `1px solid ${T.line}` }}
          />
          <button onClick={() => setQty((q) => Math.min(availablePieces, q + 1))} className="w-6 h-6 rounded flex items-center justify-center" style={{ background: T.paper, border: `1px solid ${T.line}` }}>
            <Plus size={11} />
          </button>
        </div>
      )}

      {availablePieces > 0 && hasCartons && (
        <div className="flex flex-col items-end gap-1 shrink-0">
          {cartonMode ? (
            <div className="flex items-center gap-1">
              <button onClick={() => setCartonCount((c) => Math.max(1, c - 1))} className="w-6 h-6 rounded flex items-center justify-center" style={{ background: T.paper, border: `1px solid ${T.line}` }}>
                <Minus size={11} />
              </button>
              <span className="text-xs w-14 text-center" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{cartonCount} {baseUnit}</span>
              <button onClick={() => setCartonCount((c) => Math.min(maxCartons, c + 1))} className="w-6 h-6 rounded flex items-center justify-center" style={{ background: T.paper, border: `1px solid ${T.line}` }}>
                <Plus size={11} />
              </button>
            </div>
          ) : (
            <select
              value={partialQty}
              onChange={(e) => setPartialQty(Number(e.target.value))}
              className="text-xs rounded-lg py-1 px-2 outline-none"
              style={{ fontFamily: "'JetBrains Mono', monospace", background: "#fff", border: `1px solid ${T.line}`, color: T.ink }}
            >
              {Array.from({ length: unitsPerCarton - 1 }, (_, i) => unitsPerCarton - 1 - i).map((n) => (
                <option key={n} value={n}>{n} {subUnit}</option>
              ))}
            </select>
          )}
          <button onClick={() => setCartonMode((m) => !m)} className="text-[10px] font-medium underline" style={{ color: T.sealDeep }}>
            {cartonMode ? `أقل من ${baseUnit} واحد؟` : `الرجوع لـ${baseUnit} كامل`}
          </button>
        </div>
      )}

      <button
        onClick={() => onAdd(listing, finalQty)}
        disabled={availablePieces <= 0}
        className="shrink-0 text-xs font-medium px-3 py-2 rounded-lg flex items-center gap-1"
        style={{
          background: availablePieces <= 0 ? T.paperDeep : inCart ? T.goodBg : T.ink,
          color: availablePieces <= 0 ? T.sub : inCart ? T.good : "#fff",
        }}
      >
        {inCart ? <CheckCircle2 size={13} /> : <Plus size={13} />}
        {availablePieces <= 0 ? "غير متوفر" : inCart ? "أُضيف" : "إضافة"}
      </button>
    </div>
    {showCompare && (
      <ComparePricesModal
        catalogId={listing.catalog_id}
        productName={listing.product_catalog.name}
        currentTraderId={listing.trader_id}
        onClose={() => setShowCompare(false)}
        onAdd={onAdd}
      />
    )}
    </>
  );
}

function CartDrawer({ cart, setCart, onClose, session, city, zone, distanceKm }) {
  const [placing, setPlacing] = useState(false);
  const [err, setErr] = useState("");
  const [success, setSuccess] = useState(null);
  const [vehicleType, setVehicleType] = useState("");
  const [deliverySpeed, setDeliverySpeed] = useState("standard");

  const setQty = (key, qty) => {
    const updated = cart.map((c) => (c.key === key ? { ...c, quantity: Math.max(1, qty) } : c));
    setCart(updated);
    saveCart(updated);
  };

  const removeItem = (key) => {
    const updated = cart.filter((c) => c.key !== key);
    setCart(updated);
    saveCart(updated);
  };

  const byTrader = cart.reduce((acc, item) => {
    (acc[item.trader_id] ||= { store_name: item.store_name, items: [] }).items.push(item);
    return acc;
  }, {});

  const subtotal = cart.reduce((s, c) => s + c.wholesale_price * c.quantity, 0);
  const traderCount = Object.keys(byTrader).length;
  const SIZE_WEIGHT = { light: 1, medium: 2, bulky: 4 };
  const totalLoadUnits = cart.reduce((s, c) => s + (SIZE_WEIGHT[c.shipping_size] || 2) * c.quantity, 0);

  const effectiveZone = zone || "inside_city";
  const effectiveDistance = distanceKm ?? 10;

  const feeTier = (() => {
    let tier = totalLoadUnits <= 18 && effectiveZone === "inside_city" ? "small_car"
      : totalLoadUnits <= 35 ? "pickup"
      : totalLoadUnits <= 70 ? "van"
      : "truck";
    if (effectiveZone === "outside_city" && tier === "small_car") tier = "pickup";
    const PRICES = {
      small_car: { inside_city: 30 },
      pickup: { inside_city: 50, outside_city: 100 },
      van: { inside_city: 80, outside_city: 150 },
      truck: { inside_city: 100, outside_city: 200 },
    };
    const LABELS = { small_car: "سيارة صغيرة", pickup: "وانيت", van: "حافلة", truck: "دينا" };
    const base = PRICES[tier][effectiveZone] ?? PRICES[tier].inside_city;
    let ramp = 0;
    if (effectiveZone === "inside_city" && effectiveDistance > 20) ramp = (effectiveDistance - 20) * 0.02 * base;
    else if (effectiveZone === "outside_city" && effectiveDistance > 100) ramp = (effectiveDistance - 100) * 0.02 * base;
    return { base: base + ramp, vehicle: LABELS[tier] };
  })();

  // خارج المدينة: توصيل سريع منفرد إجباري، ما يُتاح خيار "عادي" أصلاً
  const effectiveSpeed = effectiveZone === "outside_city" ? "express" : deliverySpeed;
  const deliveryFee = traderCount === 0 ? 0 : Math.round(feeTier.base) + Math.max(traderCount - 1, 0) * 10;

  const checkout = async () => {
    setErr("");
    setPlacing(true);
    const items = cart.map((c) => ({ catalog_id: c.catalog_id, trader_id: c.trader_id, quantity: c.quantity }));
    const { data, error } = await supabase.rpc("place_order", {
      p_items: items,
      p_delivery_mode: "single_driver",
      p_delivery_city: city || null,
      p_requested_vehicle_type: vehicleType || null,
      p_delivery_speed: effectiveSpeed,
    });
    setPlacing(false);
    if (error) {
      setErr(error.message || "تعذّر إتمام الطلب.");
      return;
    }
    setSuccess(data);
    setCart([]);
    saveCart([]);
  };

  if (success) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-6" style={{ background: "rgba(20,33,59,0.55)" }}>
        <div className="w-full max-w-sm rounded-xl p-7 text-center" style={{ background: "#fff" }}>
          <CheckCircle2 className="mx-auto mb-3" size={30} style={{ color: T.good }} />
          <div className="text-sm font-semibold mb-1" style={{ color: T.ink }}>تم إنشاء الطلب بنجاح</div>
          <div className="text-xs mb-4" style={{ color: T.sub, fontFamily: "'JetBrains Mono', monospace" }}>
            رقم الطلب: {success.slice(0, 8)}
          </div>
          <button onClick={onClose} className="text-xs font-medium px-4 py-2 rounded-lg" style={{ background: T.ink, color: "#fff" }}>
            متابعة التسوّق
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex justify-end" style={{ background: "rgba(20,33,59,0.4)" }} onClick={onClose}>
      <div className="w-full max-w-sm h-full overflow-y-auto p-5" style={{ background: T.paper }} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold" style={{ color: T.ink }}>سلة الطلب</span>
          <button onClick={onClose}><X size={18} style={{ color: T.sub }} /></button>
        </div>

        {cart.length === 0 ? (
          <div className="text-xs text-center py-10" style={{ color: T.sub }}>السلة فارغة حالياً.</div>
        ) : (
          <>
            {Object.entries(byTrader).map(([traderId, group]) => (
              <div key={traderId} className="mb-4">
                <div className="text-[11px] font-medium flex items-center gap-1 mb-2" style={{ color: T.sealDeep }}>
                  <Store size={11} /> {group.store_name}
                </div>
                {group.items.map((item) => (
                  <div key={item.key} className="flex items-center gap-2 mb-2 p-2.5 rounded-lg" style={{ background: "#fff", border: `1px solid ${T.line}` }}>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-medium truncate" style={{ color: T.ink }}>{item.product_name}</div>
                      <div className="text-[11px]" style={{ color: T.sub, fontFamily: "'JetBrains Mono', monospace" }}>{item.wholesale_price} ر.س</div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={() => setQty(item.key, item.quantity - 1)} className="w-6 h-6 rounded flex items-center justify-center" style={{ background: T.paper }}>
                        <Minus size={11} />
                      </button>
                      <span className="text-xs w-5 text-center" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{item.quantity}</span>
                      <button onClick={() => setQty(item.key, item.quantity + 1)} className="w-6 h-6 rounded flex items-center justify-center" style={{ background: T.paper }}>
                        <Plus size={11} />
                      </button>
                    </div>
                    <button onClick={() => removeItem(item.key)}><X size={14} style={{ color: T.bad }} /></button>
                  </div>
                ))}
              </div>
            ))}

            <div className="rounded-lg p-3 mt-2" style={{ background: "#fff", border: `1px solid ${T.line}` }}>
              <label className="text-[11px] font-medium block mb-1" style={{ color: T.sub }}>منطقة التوصيل (محدَّدة من الإدارة وقت التوثيق)</label>
              {zone ? (
                <div className="text-xs font-medium" style={{ color: T.ink }}>
                  {effectiveZone === "inside_city" ? "داخل المدينة" : "خارج المدينة"} — {effectiveDistance} كم من مركز المدينة
                </div>
              ) : (
                <div className="text-[11px]" style={{ color: T.sealDeep }}>
                  لم تُحدَّد منطقتك بعد — سيُطبَّق سعر داخل المدينة مبدئياً، وتواصل مع الدعم لتحديدها بدقة.
                </div>
              )}
            </div>

            <div className="rounded-lg p-3 mt-2" style={{ background: "#fff", border: `1px solid ${T.line}` }}>
              <label className="text-[11px] font-medium block mb-1.5" style={{ color: T.sub }}>سرعة التوصيل</label>
              {effectiveZone === "outside_city" ? (
                <div className="text-xs px-3 py-2 rounded-lg" style={{ background: "#FBF1DD", color: T.sealDeep }}>
                  الطلبات خارج المدينة تُوصَّل توصيلاً سريعاً منفرداً إلزامياً (بدون تجميع مع طلبات أخرى)
                </div>
              ) : (
                <div className="flex gap-2">
                  <button
                    onClick={() => setDeliverySpeed("standard")}
                    className="flex-1 text-xs font-medium py-2 rounded-lg"
                    style={{ background: deliverySpeed === "standard" ? T.ink : T.paper, color: deliverySpeed === "standard" ? "#fff" : T.sub, border: `1px solid ${T.line}` }}
                  >
                    عادي (قد يُجمَّع مع طلبات أخرى)
                  </button>
                  <button
                    onClick={() => setDeliverySpeed("express")}
                    className="flex-1 text-xs font-medium py-2 rounded-lg"
                    style={{ background: deliverySpeed === "express" ? T.ink : T.paper, color: deliverySpeed === "express" ? "#fff" : T.sub, border: `1px solid ${T.line}` }}
                  >
                    سريع (توصيل منفرد فقط)
                  </button>
                </div>
              )}
            </div>

            <div className="rounded-lg p-3 mt-2" style={{ background: "#fff", border: `1px solid ${T.line}` }}>
              <label className="text-[11px] font-medium block mb-1" style={{ color: T.sub }}>نوع المركبة المفضّل للتوصيل (اختياري)</label>
              <select
                value={vehicleType}
                onChange={(e) => setVehicleType(e.target.value)}
                className="w-full text-xs rounded-lg py-2 px-2 outline-none"
                style={{ background: T.paper, border: `1px solid ${T.line}`, color: T.ink }}
              >
                <option value="">بدون تفضيل</option>
                {effectiveZone === "inside_city" && <option value="small_car">سيارة صغيرة</option>}
                <option value="pickup">وانيت</option>
                <option value="van">حافلة</option>
                <option value="truck">دينا</option>
              </select>
            </div>

            <div className="rounded-lg p-3 mt-2" style={{ background: "#fff", border: `1px solid ${T.line}` }}>
              <div className="flex justify-between text-xs mb-1" style={{ color: T.sub }}>
                <span>المجموع الفرعي</span>
                <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>{subtotal.toFixed(2)} ر.س</span>
              </div>
              <div className="flex justify-between text-xs mb-1" style={{ color: T.sub }}>
                <span>رسوم التوصيل (تقديرية — يحتاج {feeTier.vehicle} تقريباً)</span>
                <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>{deliveryFee} ر.س</span>
              </div>
              <div className="flex justify-between text-sm font-semibold pt-2 mt-2" style={{ borderTop: `1px solid ${T.line}`, color: T.ink }}>
                <span>الإجمالي التقديري</span>
                <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>{(subtotal + deliveryFee).toFixed(2)} ر.س</span>
              </div>
            </div>

            {err && (
              <div className="flex items-center gap-2 text-xs mt-3 p-3 rounded-lg" style={{ background: T.badBg, color: T.bad }}>
                <AlertTriangle size={13} /> {err}
              </div>
            )}

            <button
              onClick={checkout}
              disabled={placing}
              className="w-full mt-4 text-sm font-medium py-2.5 rounded-lg flex items-center justify-center gap-2"
              style={{ background: T.ink, color: "#fff" }}
            >
              {placing && <Loader2 size={14} className="animate-spin" />}
              تأكيد الطلب
            </button>
          </>
        )}
      </div>
    </div>
  );
}

const ORDER_STATUS_LABELS = {
  pending: "معلَّق",
  confirmed: "قيد التنفيذ",
  preparing: "قيد التحضير",
  out_for_delivery: "بالطريق إليك",
  delivered: "تم التسليم",
  cancelled: "ملغى",
};

function StarRating({ value, onChange, readOnly }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          disabled={readOnly}
          onClick={() => onChange && onChange(n)}
          onMouseEnter={() => !readOnly && setHover(n)}
          onMouseLeave={() => !readOnly && setHover(0)}
          style={{ cursor: readOnly ? "default" : "pointer", lineHeight: 0 }}
        >
          <Star size={readOnly ? 12 : 22} fill={(hover || value) >= n ? T.seal : "none"} color={T.seal} strokeWidth={1.5} />
        </button>
      ))}
    </div>
  );
}

function RatingModal({ orderId, ratedId, ratedLabel, onClose, onDone }) {
  const [stars, setStars] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [err, setErr] = useState("");

  const submit = async () => {
    if (stars === 0) {
      setErr("اختر عدد النجوم أولاً.");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.rpc("submit_rating", { p_order_id: orderId, p_rated_id: ratedId, p_stars: stars, p_comment: comment.trim() || null });
    setSubmitting(false);
    if (error) {
      setErr(error.message || "تعذّر إرسال التقييم.");
      return;
    }
    onDone();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6" style={{ background: "rgba(20,33,59,0.55)" }} onClick={onClose}>
      <div className="w-full max-w-xs rounded-xl p-5" style={{ background: "#fff" }} onClick={(e) => e.stopPropagation()}>
        <div className="text-sm font-semibold mb-1" style={{ color: T.ink }}>تقييم {ratedLabel}</div>
        <div className="text-[11px] mb-3" style={{ color: T.sub }}>تجربتك تساعد باقي المستخدمين</div>
        <div className="flex justify-center mb-4"><StarRating value={stars} onChange={setStars} /></div>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          rows={3}
          placeholder="تعليق (اختياري)"
          className="w-full text-sm rounded-lg py-2 px-3 mb-3 outline-none"
          style={{ background: T.paper, border: `1px solid ${T.line}`, color: T.ink }}
        />
        {err && <div className="text-xs mb-2" style={{ color: T.bad }}>{err}</div>}
        <button onClick={submit} disabled={submitting} className="w-full text-sm font-medium py-2.5 rounded-lg" style={{ background: T.ink, color: "#fff" }}>
          {submitting ? "..." : "إرسال التقييم"}
        </button>
      </div>
    </div>
  );
}

function ReturnRequestModal({ order, onClose, onDone }) {
  const [selected, setSelected] = useState({});
  const [reason, setReason] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [err, setErr] = useState("");

  const toggle = (item) => {
    setSelected((s) => {
      const copy = { ...s };
      if (copy[item.id]) delete copy[item.id];
      else copy[item.id] = item.quantity;
      return copy;
    });
  };

  const setQty = (itemId, qty, max) => {
    setSelected((s) => ({ ...s, [itemId]: Math.max(1, Math.min(max, qty)) }));
  };

  const submit = async () => {
    const items = Object.entries(selected).map(([order_item_id, quantity]) => ({ order_item_id, quantity }));
    if (items.length === 0) {
      setErr("اختر منتج واحد على الأقل.");
      return;
    }
    if (!reason.trim()) {
      setErr("يرجى كتابة سبب الإرجاع.");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.rpc("request_return", { p_order_id: order.id, p_items: items, p_reason: reason.trim() });
    setSubmitting(false);
    if (error) {
      setErr(error.message || "تعذّر إرسال طلب الإرجاع.");
      return;
    }
    onDone();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6" style={{ background: "rgba(20,33,59,0.55)" }} onClick={onClose}>
      <div className="w-full max-w-sm rounded-xl p-5 max-h-[85vh] overflow-y-auto" style={{ background: "#fff" }} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold" style={{ color: T.ink }}>طلب إرجاع — طلب #{order.id.slice(0, 8)}</span>
          <button onClick={onClose}><X size={18} style={{ color: T.sub }} /></button>
        </div>

        <div className="text-[11px] font-medium mb-2" style={{ color: T.sub }}>اختر المنتجات المطلوب إرجاعها</div>
        <div className="flex flex-col gap-2 mb-4">
          {(order.order_items || []).map((item) => (
            <div key={item.id} className="rounded-lg p-3" style={{ background: selected[item.id] ? "#FBF1DD" : T.paper, border: `1px solid ${T.line}` }}>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={!!selected[item.id]} onChange={() => toggle(item)} />
                <span className="text-xs flex-1" style={{ color: T.ink }}>{item.product_name} (المطلوب أصلاً: {item.quantity})</span>
              </label>
              {selected[item.id] && (
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[11px]" style={{ color: T.sub }}>الكمية المرتجعة:</span>
                  <input
                    type="number"
                    min={1}
                    max={item.quantity}
                    value={selected[item.id]}
                    onChange={(e) => setQty(item.id, Number(e.target.value), item.quantity)}
                    className="w-16 text-xs rounded-lg py-1 px-2 outline-none"
                    style={{ background: "#fff", border: `1px solid ${T.line}`, color: T.ink }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        <label className="text-[11px] font-medium block mb-1" style={{ color: T.sub }}>سبب الإرجاع</label>
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          rows={3}
          placeholder="مثال: منتج تالف، خطأ بالطلب، تغيّرت الحاجة..."
          className="w-full text-sm rounded-lg py-2 px-3 mb-3 outline-none"
          style={{ background: T.paper, border: `1px solid ${T.line}`, color: T.ink }}
        />

        {err && <div className="text-xs mb-3" style={{ color: T.bad }}>{err}</div>}

        <button
          onClick={submit}
          disabled={submitting}
          className="w-full text-sm font-medium py-2.5 rounded-lg flex items-center justify-center gap-2"
          style={{ background: T.ink, color: "#fff" }}
        >
          {submitting && <Loader2 size={14} className="animate-spin" />}
          إرسال طلب الإرجاع
        </button>
      </div>
    </div>
  );
}

function MyOrdersTab({ session }) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [returnOrder, setReturnOrder] = useState(null);
  const [returnSuccess, setReturnSuccess] = useState(false);
  const [expandedOrder, setExpandedOrder] = useState(null);
  const [ratingTarget, setRatingTarget] = useState(null); // { orderId, ratedId, label }
  const [myRatings, setMyRatings] = useState({}); // key: `${orderId}-${ratedId}`
  const [traderNames, setTraderNames] = useState({});

  const loadRatings = async () => {
    const { data } = await supabase.from("ratings").select("order_id, rated_id").eq("rater_id", session.user.id);
    const map = {};
    (data || []).forEach((r) => { map[`${r.order_id}-${r.rated_id}`] = true; });
    setMyRatings(map);
  };

  const load = () => {
    supabase
      .from("orders")
      .select("*, delivery_pin, driver:profiles!driver_id(full_name), order_items(id, product_name, quantity, unit_price, trader_id, unit_name, units_per_carton_snapshot, base_unit_name_snapshot)")
      .eq("customer_id", session.user.id)
      .order("created_at", { ascending: false })
      .then(async ({ data }) => {
        setOrders(data || []);
        setLoading(false);
        const traderIds = [...new Set((data || []).flatMap((o) => (o.order_items || []).map((i) => i.trader_id)))];
        if (traderIds.length) {
          const { data: traders } = await supabase.from("profiles").select("id, store_name, full_name").in("id", traderIds);
          const names = {};
          (traders || []).forEach((t) => { names[t.id] = t.store_name || t.full_name; });
          setTraderNames(names);
        }
      });
    loadRatings();
  };

  useEffect(load, [session]);

  if (loading) return <div className="flex justify-center py-10"><Loader2 className="animate-spin" size={18} style={{ color: T.sealDeep }} /></div>;
  if (orders.length === 0) {
    return (
      <div className="text-sm text-center py-10 rounded-xl" style={{ background: "#fff", border: `1px solid ${T.line}`, color: T.sub }}>
        لا توجد طلبات سابقة بعد.
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {orders.map((o) => (
        <div key={o.id} className="rounded-xl p-4" style={{ background: "#fff", border: `1px solid ${T.line}` }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px]" style={{ color: T.sub, fontFamily: "'JetBrains Mono', monospace" }}>
              طلب #{o.id.slice(0, 8)} · {new Date(o.created_at).toLocaleDateString("ar-SA")}
            </span>
            <span
              className="text-[10px] font-medium px-2 py-0.5 rounded-full"
              style={{
                background: o.status === "delivered" ? T.goodBg : "#FBF1DD",
                color: o.status === "delivered" ? T.good : T.sealDeep,
              }}
            >
              {ORDER_STATUS_LABELS[o.status] || o.status}
            </span>
          </div>
          <button
            onClick={() => setExpandedOrder(expandedOrder === o.id ? null : o.id)}
            className="text-[11px] mb-2 underline"
            style={{ color: T.sub }}
          >
            {(o.order_items || []).length} صنف · {[...new Set((o.order_items || []).map((i) => i.trader_id))].length} تاجر
          </button>
          {expandedOrder === o.id && (
            <div className="rounded-lg p-2.5 mb-2" style={{ background: T.paper }}>
              {(o.order_items || []).map((item) => (
                <div key={item.id} className="flex items-center justify-between text-[11px] py-1" style={{ color: T.ink }}>
                  <span>
                    {item.product_name} × {item.quantity} {item.unit_name || "وحدة"}
                    {item.units_per_carton_snapshot > 1 && item.quantity % item.units_per_carton_snapshot === 0 && (
                      <span style={{ color: T.sub }}> (= {item.quantity / item.units_per_carton_snapshot} {item.base_unit_name_snapshot})</span>
                    )}
                  </span>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", color: T.sub }}>{(item.quantity * item.unit_price).toFixed(2)} ر.س</span>
                </div>
              ))}
            </div>
          )}
          {o.status !== "delivered" && o.status !== "cancelled" && o.delivery_pin && (
            <div className="rounded-lg p-2.5 mb-2 flex items-center justify-between" style={{ background: "#FBF1DD" }}>
              <span className="text-[11px]" style={{ color: T.sealDeep }}>رمز التسليم — أعطه للسائق عند الاستلام</span>
              <span className="text-base font-bold" style={{ color: T.sealDeep, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.2em" }}>{o.delivery_pin}</span>
            </div>
          )}
          <div className="flex items-center justify-between text-[11px] mb-1" style={{ color: T.sub }}>
            <span>المنتجات: {o.subtotal} ر.س</span>
            <span>التوصيل: {o.delivery_fee} ر.س</span>
          </div>
          {o.status === "delivered" && (
            <div className="flex flex-wrap items-center gap-1.5 mb-2">
              {[...new Set((o.order_items || []).map((i) => i.trader_id))].map((tid) => (
                myRatings[`${o.id}-${tid}`] ? (
                  <span key={tid} className="text-[10px] font-medium px-2 py-1 rounded-full" style={{ background: T.goodBg, color: T.good }}>
                    ✓ قيّمت {traderNames[tid] || "التاجر"}
                  </span>
                ) : (
                  <button
                    key={tid}
                    onClick={() => setRatingTarget({ orderId: o.id, ratedId: tid, label: traderNames[tid] || "التاجر" })}
                    className="text-[10px] font-medium px-2 py-1 rounded-full flex items-center gap-1"
                    style={{ background: "#FBF1DD", color: T.sealDeep, border: "1px solid #E8D5A8" }}
                  >
                    <Star size={10} /> قيّم {traderNames[tid] || "التاجر"}
                  </button>
                )
              ))}
              {o.driver_id && (
                myRatings[`${o.id}-${o.driver_id}`] ? (
                  <span className="text-[10px] font-medium px-2 py-1 rounded-full" style={{ background: T.goodBg, color: T.good }}>
                    ✓ قيّمت السائق
                  </span>
                ) : (
                  <button
                    onClick={() => setRatingTarget({ orderId: o.id, ratedId: o.driver_id, label: o.driver?.full_name || "السائق" })}
                    className="text-[10px] font-medium px-2 py-1 rounded-full flex items-center gap-1"
                    style={{ background: "#FBF1DD", color: T.sealDeep, border: "1px solid #E8D5A8" }}
                  >
                    <Star size={10} /> قيّم السائق
                  </button>
                )
              )}
            </div>
          )}
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold" style={{ fontFamily: "'JetBrains Mono', monospace", color: T.ink }}>
              الإجمالي: {o.total} ر.س
            </span>
            {o.status === "delivered" && (
              <button onClick={() => setReturnOrder(o)} className="text-[11px] font-medium px-3 py-1.5 rounded-lg" style={{ background: T.badBg, color: T.bad }}>
                طلب إرجاع
              </button>
            )}
          </div>
        </div>
      ))}

      {ratingTarget && (
        <RatingModal
          orderId={ratingTarget.orderId}
          ratedId={ratingTarget.ratedId}
          ratedLabel={ratingTarget.label}
          onClose={() => setRatingTarget(null)}
          onDone={() => { setRatingTarget(null); loadRatings(); }}
        />
      )}

      {returnOrder && (
        <ReturnRequestModal
          order={returnOrder}
          onClose={() => setReturnOrder(null)}
          onDone={() => { setReturnOrder(null); setReturnSuccess(true); setTimeout(() => setReturnSuccess(false), 3000); load(); }}
        />
      )}
      {returnSuccess && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 text-xs font-medium px-4 py-2.5 rounded-lg" style={{ background: T.good, color: "#fff" }}>
          تم إرسال طلب الإرجاع، بانتظار رد التاجر
        </div>
      )}
    </div>
  );
}

function LoyaltyPointsCard({ points, onRedeemed }) {
  const [redeemPoints, setRedeemPoints] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [success, setSuccess] = useState(false);

  const redeem = async () => {
    setErr("");
    const p = Number(redeemPoints);
    if (!p || p <= 0 || p > (points || 0)) {
      setErr("أدخل عدد نقاط صحيح ومتوفر برصيدك.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.rpc("redeem_points_to_wallet", { p_points: p });
    setBusy(false);
    if (error) {
      setErr(error.message || "تعذّر التحويل.");
      return;
    }
    setRedeemPoints("");
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2500);
    onRedeemed();
  };

  return (
    <div className="rounded-xl p-4 mb-4" style={{ background: "#FBF1DD", border: "1px solid #E8D5A8" }}>
      <div className="text-[11px]" style={{ color: T.sealDeep }}>نقاط الولاء</div>
      <div className="text-2xl font-semibold mt-1" style={{ fontFamily: "'JetBrains Mono', monospace", color: T.sealDeep }}>
        {points || 0} <span className="text-xs font-normal">نقطة</span>
      </div>
      <div className="text-[10px] mt-1 mb-2" style={{ color: T.sealDeep }}>تكسب نقطة عن كل 10 ريال بمشترياتك — 10 نقاط = 1 ريال</div>
      <div className="flex items-center gap-2">
        <input
          type="number"
          value={redeemPoints}
          onChange={(e) => setRedeemPoints(e.target.value)}
          placeholder="عدد النقاط"
          className="flex-1 text-xs rounded-lg py-1.5 px-2 outline-none"
          style={{ background: "#fff", border: "1px solid #E8D5A8", color: T.ink }}
        />
        <button onClick={redeem} disabled={busy} className="text-xs font-medium px-3 py-1.5 rounded-lg" style={{ background: T.ink, color: "#fff" }}>
          {busy ? "..." : success ? "تم ✓" : "تحويل لرصيد"}
        </button>
      </div>
      {err && <div className="text-[11px] mt-1.5" style={{ color: T.bad }}>{err}</div>}
    </div>
  );
}

function CustomerWalletDrawer({ session, balance, points, onClose, onPointsChanged }) {
  const [orders, setOrders] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);
  const [itemsCache, setItemsCache] = useState({});

  useEffect(() => {
    Promise.all([
      supabase.from("orders").select("id, subtotal, delivery_fee, total, status, created_at").eq("customer_id", session.user.id).eq("status", "delivered").order("created_at", { ascending: false }),
      supabase.from("wallet_transactions").select("*").eq("customer_id", session.user.id).order("created_at", { ascending: false }),
    ]).then(([o, t]) => {
      setOrders(o.data || []);
      setTransactions(t.data || []);
      setLoading(false);
    });
  }, [session]);

  const toggleExpand = async (orderId) => {
    if (expanded === orderId) {
      setExpanded(null);
      return;
    }
    setExpanded(orderId);
    if (!itemsCache[orderId]) {
      const { data } = await supabase
        .from("order_items")
        .select("trader_id, product_name, quantity, line_total, profiles!trader_id(store_name)")
        .eq("order_id", orderId);
      setItemsCache((c) => ({ ...c, [orderId]: data || [] }));
    }
  };

  const totalSpent = orders.reduce((s, o) => s + Number(o.total ?? o.subtotal), 0);

  return (
    <div className="fixed inset-0 z-50 flex justify-end" style={{ background: "rgba(20,33,59,0.4)" }} onClick={onClose}>
      <div className="w-full max-w-sm h-full overflow-y-auto p-5" style={{ background: T.paper }} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-semibold flex items-center gap-1.5" style={{ color: T.good }}><Wallet size={15} /> محفظتي</span>
          <button onClick={onClose}><X size={18} style={{ color: T.sub }} /></button>
        </div>

        {loading ? (
          <div className="flex justify-center py-10"><Loader2 className="animate-spin" size={18} style={{ color: T.sealDeep }} /></div>
        ) : (
          <>
            <div className="rounded-xl p-4 mb-4" style={{ background: T.goodBg, border: "1px solid #BFE0CE" }}>
              <div className="text-[11px]" style={{ color: T.good }}>الرصيد الدائن الحالي</div>
              <div className="text-2xl font-semibold mt-1" style={{ fontFamily: "'JetBrains Mono', monospace", color: T.good }}>
                {balance || 0} <span className="text-xs font-normal">ر.س</span>
              </div>
              <div className="text-[10px] mt-1" style={{ color: T.good }}>يُستخدم من مرتجعات أو تعويضات، يعتمده المدير أو المشرف المالي</div>
            </div>

            <LoyaltyPointsCard points={points} onRedeemed={onPointsChanged} />

            <div className="rounded-xl p-4 mb-4" style={{ background: "#fff", border: `1px solid ${T.line}` }}>
              <div className="text-[11px]" style={{ color: T.sub }}>إجمالي ما دفعته (طلبات مكتملة)</div>
              <div className="text-xl font-semibold mt-1" style={{ fontFamily: "'JetBrains Mono', monospace", color: T.ink }}>
                {totalSpent.toFixed(2)} <span className="text-xs font-normal" style={{ color: T.sub }}>ر.س</span>
              </div>
            </div>

            {orders.length > 0 && (
              <div className="mb-4">
                <div className="text-xs font-medium mb-2" style={{ color: T.ink }}>طلباتي السابقة (تفصيل حسب التاجر)</div>
                <div className="flex flex-col gap-2">
                  {orders.map((o) => (
                    <div key={o.id} className="rounded-xl overflow-hidden" style={{ background: "#fff", border: `1px solid ${T.line}` }}>
                      <button onClick={() => toggleExpand(o.id)} className="w-full flex items-center gap-3 p-3 text-right">
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-medium" style={{ color: T.ink, fontFamily: "'JetBrains Mono', monospace" }}>
                            طلب #{o.id.slice(0, 8)}
                          </div>
                          <div className="text-[10px]" style={{ color: T.sub }}>{new Date(o.created_at).toLocaleDateString("ar-SA")}</div>
                        </div>
                        <span className="text-xs font-semibold" style={{ fontFamily: "'JetBrains Mono', monospace", color: T.ink }}>
                          {(o.total ?? o.subtotal)} ر.س
                        </span>
                      </button>
                      {expanded === o.id && (
                        <div className="px-3 pb-3" style={{ borderTop: `1px solid ${T.line}` }}>
                          <div className="text-[10px] pt-2 pb-1" style={{ color: T.sub }}>
                            المنتجات: {o.subtotal} ر.س + التوصيل: {o.delivery_fee} ر.س
                          </div>
                          {(() => {
                            const items = itemsCache[o.id] || [];
                            const byTraderMap = items.reduce((acc, it) => {
                              const name = it.profiles?.store_name || "متجر";
                              (acc[name] ||= 0);
                              acc[name] += Number(it.line_total);
                              return acc;
                            }, {});
                            return Object.entries(byTraderMap).map(([name, amount]) => (
                              <div key={name} className="flex items-center justify-between text-xs py-1" style={{ color: T.ink }}>
                                <span className="flex items-center gap-1"><Store size={11} style={{ color: T.sealDeep }} /> {name}</span>
                                <span style={{ fontFamily: "'JetBrains Mono', monospace", color: T.sub }}>{amount.toFixed(2)} ر.س</span>
                              </div>
                            ));
                          })()}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {transactions.length > 0 && (
              <div>
                <div className="text-xs font-medium mb-2" style={{ color: T.ink }}>حركات الرصيد</div>
                <div className="flex flex-col gap-2">
                  {transactions.map((t) => (
                    <div key={t.id} className="rounded-lg p-3 flex items-center justify-between" style={{ background: "#fff", border: `1px solid ${T.line}` }}>
                      <div>
                        <div className="text-xs" style={{ color: T.ink }}>{t.reason}</div>
                        <div className="text-[10px]" style={{ color: T.sub }}>{new Date(t.created_at).toLocaleDateString("ar-SA")}</div>
                      </div>
                      <span className="text-xs font-semibold" style={{ fontFamily: "'JetBrains Mono', monospace", color: t.amount >= 0 ? T.good : T.bad }}>
                        {t.amount >= 0 ? "+" : ""}{t.amount} ر.س
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default function ProductBrowse() {
  useFonts();
  useIdleLogout(30);
  const [session, setSession] = useState(null);
  const [checking, setChecking] = useState(true);
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [traderFilter, setTraderFilter] = useState("");
  const [traders, setTraders] = useState([]);
  const [cart, setCart] = useState(loadCart());
  const [showCart, setShowCart] = useState(false);
  const [tab, setTab] = useState("browse");
  const [profile, setProfile] = useState(null);
  const [showWallet, setShowWallet] = useState(false);
  const [authorized, setAuthorized] = useState(null);

  useEffect(() => {
    if (!session) return;
    supabase
      .from("user_roles")
      .select("role_id")
      .eq("user_id", session.user.id)
      .in("role_id", ["business_customer", "individual_customer"])
      .maybeSingle()
      .then(({ data }) => setAuthorized(!!data));
  }, [session]);
  const [appAd, setAppAd] = useState(null);

  useEffect(() => {
    supabase.rpc("get_active_ads", { p_placement: "customer_app" }).then(({ data }) => {
      const b = (data || []).find((a) => a.slot_id === "app_banner");
      if (b) {
        setAppAd({ ...b, url: supabase.storage.from("ad-creatives").getPublicUrl(b.media_path).data.publicUrl });
        supabase.rpc("log_ad_view", { p_booking_id: b.id }).then(({ error }) => {
          if (error) console.error("log_ad_view error:", error);
        });
      }
    });
  }, []);

  const reloadProfile = () => {
    if (session) {
      supabase.from("profiles").select("full_name, business_name, city, wallet_balance, delivery_zone, distance_km, loyalty_points").eq("id", session.user.id).single()
        .then(({ data }) => setProfile(data));
    }
  };

  useEffect(reloadProfile, [session]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setChecking(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    supabase
      .from("profiles")
      .select("id, store_name, city, user_roles!inner(role_id)")
      .eq("store_launch_status", "launched")
      .eq("user_roles.role_id", "trader")
      .order("store_name", { ascending: true })
      .then(({ data }) => setTraders(data || []));
  }, []);

  const fetchPage = useCallback(async (pageNum, reset) => {
    setLoading(true);
    let query = supabase
      .from("trader_listings")
      .select("id, quantity, wholesale_price, units_per_carton, base_unit_name, sub_unit_name, trader_id, catalog_id, product_catalog!inner(name, category_id, status, shipping_size), profiles!trader_id!inner(store_name, city, store_launch_status, avg_rating, ratings_count)")
      .eq("active", true)
      .eq("profiles.store_launch_status", "launched")
      .order("id", { ascending: true })
      .range(pageNum * PAGE_SIZE, pageNum * PAGE_SIZE + PAGE_SIZE - 1);

    if (category) query = query.eq("product_catalog.category_id", category);
    if (traderFilter) query = query.eq("trader_id", traderFilter);
    if (search.trim()) query = query.ilike("product_catalog.name", `%${search.trim()}%`);

    const { data, error } = await query;
    if (!error) {
      setListings((prev) => (reset ? data : [...prev, ...data]));
      setHasMore((data || []).length === PAGE_SIZE);
    }
    setLoading(false);
  }, [category, search, traderFilter]);

  useEffect(() => {
    setPage(0);
    fetchPage(0, true);
  }, [category, search, traderFilter, fetchPage]);

  const addToCart = (listing, chosenQty = 1) => {
    const key = `${listing.trader_id}-${listing.catalog_id}`;
    const existing = cart.find((c) => c.key === key);
    let updated;
    if (existing) {
      updated = cart.map((c) => (c.key === key ? { ...c, quantity: c.quantity + chosenQty } : c));
    } else {
      updated = [
        ...cart,
        {
          key,
          catalog_id: listing.catalog_id,
          trader_id: listing.trader_id,
          product_name: listing.product_catalog.name,
          store_name: listing.profiles?.store_name || "متجر غير مسمّى",
          wholesale_price: listing.wholesale_price / (listing.units_per_carton || 1),
          quantity: chosenQty,
          shipping_size: listing.product_catalog?.shipping_size || "medium",
        },
      ];
    }
    setCart(updated);
    saveCart(updated);
  };

  const cartCount = cart.reduce((s, c) => s + c.quantity, 0);

  if (checking || (session && authorized === null)) {
    return (
      <div className="w-full h-screen flex items-center justify-center" style={{ background: T.paper }}>
        <Loader2 className="animate-spin" style={{ color: T.sealDeep }} />
      </div>
    );
  }
  if (!session || authorized === false) return <Navigate to="/login" replace />;

  return (
    <div dir="rtl" className="w-full min-h-screen" style={{ fontFamily: "'IBM Plex Sans Arabic', sans-serif", background: T.paper }}>
      <header className="px-6 md:px-10 py-4 flex items-center justify-between sticky top-0 z-20" style={{ background: T.paper, borderBottom: `1px solid ${T.line}` }}>
        <Link to="/" className="flex items-center gap-2" style={{ textDecoration: "none" }} title="الصفحة الرئيسية">
          <div className="w-9 h-9 rounded-md flex items-center justify-center rotate-3" style={{ background: T.seal }}>
            <Package size={18} color={T.ink} strokeWidth={2.5} />
          </div>
          <div>
            <div className="font-semibold text-[15px]" style={{ color: T.ink }}>أصناف الجملة</div>
            <div className="text-[11px]" style={{ color: T.sub }}>
              {profile?.full_name ? `أهلاً بك، ${profile.full_name}` : "تصفّح المنتجات"}
            </div>
          </div>
        </Link>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowWallet(true)} className="relative flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg" style={{ background: T.goodBg, color: T.good, border: `1px solid #BFE0CE` }}>
            <Wallet size={13} /> محفظتي
            {profile?.wallet_balance > 0 && (
              <span className="text-[10px] font-bold" style={{ fontFamily: "'JetBrains Mono', monospace" }}>({profile.wallet_balance} ر.س)</span>
            )}
          </button>
          <button onClick={() => setShowCart(true)} className="relative flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg" style={{ background: T.ink, color: "#fff" }}>
            <ShoppingCart size={13} /> السلة
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -left-1.5 w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold" style={{ background: T.seal, color: T.ink }}>
                {cartCount}
              </span>
            )}
          </button>
          <button onClick={() => supabase.auth.signOut()} className="text-xs font-medium flex items-center gap-1.5" style={{ color: T.sub }}>
            <LogOut size={14} /> خروج
          </button>
        </div>
      </header>

      <div className="p-6 md:p-10 max-w-3xl mx-auto">
        <div className="rounded-xl p-4 mb-5 flex items-center gap-3" style={{ background: T.goodBg, border: `1px solid #BFE0CE` }}>
          <Package size={20} style={{ color: T.good }} />
          <div>
            <div className="text-sm font-semibold" style={{ color: T.ink }}>
              أهلاً بك، {profile?.full_name || "..."}
            </div>
            <div className="text-[11px]" style={{ color: T.sub }}>
              هذه لوحة التحكم الخاصة بالعميل <span className="font-bold" style={{ color: T.ink }}>{profile?.business_name || "..."}</span> على منصة أصناف الجملة
            </div>
          </div>
        </div>
        <div className="flex gap-2 mb-5">
          <button
            onClick={() => setTab("browse")}
            className="flex-1 text-xs font-medium py-2.5 rounded-lg"
            style={{ background: tab === "browse" ? T.ink : "#fff", color: tab === "browse" ? "#fff" : T.sub, border: `1px solid ${T.line}` }}
          >
            تصفّح المنتجات
          </button>
          <button
            onClick={() => setTab("orders")}
            className="flex-1 text-xs font-medium py-2.5 rounded-lg"
            style={{ background: tab === "orders" ? T.ink : "#fff", color: tab === "orders" ? "#fff" : T.sub, border: `1px solid ${T.line}` }}
          >
            طلباتي
          </button>
        </div>

        {tab === "orders" ? (
          <MyOrdersTab session={session} />
        ) : (
        <>
        {appAd && (
          <a href={appAd.link_url || "#"} className="block rounded-xl overflow-hidden mb-4" style={{ border: `1px solid ${T.line}`, aspectRatio: "1000 / 250", maxHeight: 140 }}>
            <img src={appAd.url} alt="إعلان" className="w-full h-full object-cover" />
          </a>
        )}
        <div className="flex gap-2 mb-5">
          <div className="relative flex-1">
            <Search size={15} className="absolute top-1/2 -translate-y-1/2 right-3" style={{ color: T.sub }} />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث عن منتج..."
              className="w-full text-sm rounded-lg py-2 pe-9 ps-3 outline-none"
              style={{ background: "#fff", border: `1px solid ${T.line}`, color: T.ink }}
            />
          </div>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="text-sm rounded-lg px-3 outline-none"
            style={{ background: "#fff", border: `1px solid ${T.line}`, color: T.ink }}
          >
            {CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>{c.label}</option>
            ))}
          </select>
          <select
            value={traderFilter}
            onChange={(e) => setTraderFilter(e.target.value)}
            className="text-sm rounded-lg px-3 outline-none"
            style={{ background: "#fff", border: `1px solid ${T.line}`, color: T.ink }}
          >
            <option value="">كل التجّار</option>
            {traders.map((t) => (
              <option key={t.id} value={t.id}>{t.store_name || "متجر غير مسمّى"} — {t.city}</option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-3">
          {listings.map((l) => (
            <ProductRow key={l.id} listing={l} onAdd={addToCart} inCart={cart.some((c) => c.key === `${l.trader_id}-${l.catalog_id}`)} />
          ))}
        </div>

        {loading && (
          <div className="flex justify-center py-6"><Loader2 className="animate-spin" size={18} style={{ color: T.sealDeep }} /></div>
        )}

        {!loading && listings.length === 0 && (
          <div className="text-sm text-center py-10 rounded-xl" style={{ background: "#fff", border: `1px solid ${T.line}`, color: T.sub }}>
            لا توجد منتجات مطابقة حالياً.
          </div>
        )}

        {!loading && hasMore && listings.length > 0 && (
          <button
            onClick={() => { const next = page + 1; setPage(next); fetchPage(next, false); }}
            className="w-full mt-4 text-xs font-medium py-2.5 rounded-lg"
            style={{ background: "#fff", border: `1px solid ${T.line}`, color: T.sub }}
          >
            عرض المزيد
          </button>
        )}
        </>
        )}
      </div>

      {showCart && <CartDrawer cart={cart} setCart={setCart} onClose={() => setShowCart(false)} session={session.user} city={profile?.city} zone={profile?.delivery_zone} distanceKm={profile?.distance_km} />}
      {showWallet && <CustomerWalletDrawer session={session} balance={profile?.wallet_balance} points={profile?.loyalty_points} onClose={() => setShowWallet(false)} onPointsChanged={reloadProfile} />}
    </div>
  );
}
